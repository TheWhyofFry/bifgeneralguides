#!/bin/bash
for FILENAME in *.mod; do MODELLINE=$(grep "Best model according to AIC" ${FILENAME}); MODEL=${MODELLINE#*AIC: }; OUTFILE=${FILENAME%%.mod}.fas; echo ${OUTFILE},${MODEL}; done
